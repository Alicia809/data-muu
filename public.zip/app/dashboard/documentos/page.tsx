"use client"

import DocumentosPage from "./generacion-documentos"

export default DocumentosPage