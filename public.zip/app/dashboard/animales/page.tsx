"use client"

import RegistroAnimales from "./registro-animales"

export default RegistroAnimales
