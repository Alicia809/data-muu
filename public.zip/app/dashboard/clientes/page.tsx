"use client"

import RegistroClientes from "./registro-clientes"

export default RegistroClientes
