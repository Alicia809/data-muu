"use client"

import RegistroHerraduras from "./registro-herraduras"

export default RegistroHerraduras
